from django import forms # type: ignore
from .models import Task, Resource

class AddTaskForms(forms.ModelForm):
    model = Task
    fiels = ("name", "role")
    Widgets = {
        'name':forms.TextInput(attrs={'class': 'form-control'}),
        'role':forms.TextInput(attrs={'class': 'form-control'}),
    }

class ResourceForm(forms.ModelForm):
    model = Resource
    fiels = ('allocation', 'budget', 'date')
    Widgets = {
        'allocation':forms.TextInput(attrs={'class': 'form-control'}),
        'budget':forms.TextInput(attrs={'class': 'form-control'}),
        'date':forms.TextInput(attrs={'class': 'form-control'}),
    }