from django.shortcuts import render, HttpResponse, redirect # type: ignore
from django.contrib.auth.models import User # type: ignore
from django.contrib import messages # type: ignore
from django.contrib.auth import authenticate, login, logout   # type: ignore
from .models import Task, Management, Resource, Progresses

# Create your views here....

def SignupPage(request):
    if request.method == 'POST':
        uname = request.POST.get('username')
        email = request.POST.get('email')
        pass1 = request.POST.get('password1')
        pass2 = request.POST.get('password2')

        if pass1 != pass2:
           messages.success(request, 'passowords are not the same');
        else:
            my_user=User.objects.create_user(uname,email,pass1);
            my_user.save()
            messages.success(request, 'Sucessfuly!! you signup');
            return redirect('login')
        
    return render(request, 'signup.html');

def LoginPage(request):
    if request.method=='POST':
        username=request.POST.get('username')
        pass1=request.POST.get('pass')
        user=authenticate(request, username=username,password=pass1)
        if user is not None:
            login(request, user)
            messages.success(request, ('You have been loged-in!!'))
            return redirect('homeuser')
        else:
            messages.success(request, ('There is an error, failed to log-in!!'))
            return redirect('login')
        
    else:    

        return render(request, 'login.html', {});

def HomePage(request):
    return render(request, 'home.html');

def DashBoard(request):
    return render(request, 'dashboard.html');

def AdminLogin(request):
     if request.method=='POST':
        username=request.POST.get('username')
        pass1=request.POST.get('pass')
        user=authenticate(request, username=username,password=pass1)
        if user is not None:
            login(request, user)
            return redirect('Admindashboard')
        else:
            return  HttpResponse('Username or password is incorrect!!')

     return render(request, 'admin_login.html');

def UserHome(request):
    task_data = Task.objects.all()
    return render(request, 'userhome.html', {'taskdata': task_data});
            
def AddTask(request):
    if request.method == "POST":
        name=request.POST['name']
        role=request.POST['role']
        task=Task(name=name, role=role)
        task.save()

    return render(request, 'addTask.html');

def AdminPage(request):
    task = Task.objects.all()
    management = Management.objects.all()
    resource = Resource.objects.all()
    progress = Progresses.objects.all()
    total_task = task.count()
    total_management = management.count()
    total_resource = resource.count()
    total_progres = progress.count()

    total = sum([total_task, total_management, total_resource]);

    return render(request, 'Admindashboard.html', {'tasktotal': total_task, 'totalmanagement': total_management, 'totalresource':total_resource,'totalprogres': total_progres});

def AdminDASH(request):
    return render(request, 'AdminDash.html');

def HomeUser(request):
    return render(request, 'homeuser.html');

def BudgetManagement(request):
     management_data = Management.objects.all()
     return render(request, 'budget.html', {'managementdata': management_data});

def AddManagement(request):
    if request.method == "POST":
        newarea=request.POST['newarea']
        cost=request.POST['cost']
        date=request.POST['date']
        management=Management(newarea=newarea, cost=cost, date=date)
        management.save()
        return redirect('budget')
    return render(request, 'addbudget.html');

def Delete_budget(request, pk):
    management = Management.objects.get(id=pk)
    if request.method == "POST":
        management.delete()
        return redirect('budget')
    context = {
        'management_data': management
    }
    return render(request, 'delete-budget.html', context)
    

def User_logout(request):
    logout(request)
    messages.success(request, ('You have loged out!!'))
    return redirect('homeuser.html')

def ViewTask(request):
    task_data = Task.objects.all()
    return render(request, 'viewtask.html', {'taskdata': task_data});

def Delete_task(request, pk):
    task = Task.objects.get(id=pk)
    if request.method == "POST":
        task.delete()
        return redirect('viewtask')
    context = {
        'task_data': task
    }
    return render(request, 'delete-task.html', context)
    

def IndexPage(request):
    return render(request, 'index.html');


def ContactUs(request):
    return render(request, 'contactus.html');

def AboutUs(request):
    return render(request, 'aboutus.html');

def AddResource(request):
    if request.method == "POST":
        allocation = request.POST['allocation']
        budget = request.POST['budget']
        date = request.POST['date']
        resource=Resource(allocation=allocation, budget=budget, date=date)
        resource.save()
        return redirect('viewResource')
    return render(request, 'resource.html');

def ViewResource(request):
    resource_data = Resource.objects.all()
    return render(request, 'viewResource.html', {'resourcedata': resource_data});

def Delete_resource(request, pk):
    resource = Resource.objects.get(id=pk)
    if request.method == "POST":
        resource.delete()
        return redirect('viewResource')
    context = {
        'resource_data': resource
    }
    return render(request, 'delete.html', context)

def ResourceView(request):
    resource_data = Resource.objects.all()
    return render(request, 'userResource.html', {'resourcedata': resource_data});

def ProressTrack(request):
    return render(request, 'progress.html');

def AddProgress(request):
    if request.method == "POST":
        task=request.POST['task']
        budget=request.POST['budget']
        date=request.POST['date']
        status=request.POST['status']
        progress=Progresses(task=task, budget=budget, date=date, status=status)
        progress.save()
        return redirect('progress')
    return render(request, 'addprogress.html');

def ProgressView(request):
    progress_data = Progresses.objects.all()
    return render(request, 'progress.html', {'progressdata': progress_data});

def DeleteProgress(request, pk):
    progress = Progresses.objects.get(id=pk)
    if request.method == "POST":
        progress.delete()
        return redirect('progress')
    context = {
        'resource_data': progress
    }
    return render(request, 'delete-progress.html', context)