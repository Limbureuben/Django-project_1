from django.contrib import admin # type: ignore
from .models import Task, Management, Resource, Progresses

# Register your models here....
@admin.register(Task)
class TaskAdmin(admin.ModelAdmin):
    list_display = ['id', 'name', 'role']

@admin.register(Management)
class ManagementAdmin(admin.ModelAdmin):
    list_display = ['id', 'newarea', 'cost', 'date']

@admin.register(Resource)
class ResourceAdmin(admin.ModelAdmin):
    list_display = ['id', 'allocation', 'budget', 'date']

@admin.register(Progresses)
class ProgressesAdmin(admin.ModelAdmin):
    list_display = ['id', 'task', 'budget', 'date', 'status']

