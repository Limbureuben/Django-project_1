from django.test import TestCase # type: ignore

# Create your tests here.
