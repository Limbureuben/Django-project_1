from django.db import models # type: ignore

# Create your models here..
class Task(models.Model):
    name = models.CharField(max_length=50)
    role = models.CharField(max_length=200)

class Management(models.Model):
    newarea = models.CharField(max_length=200)
    cost = models.CharField(max_length=100)
    date = models.DateField(max_length=50)

class Resource(models.Model):
    allocation = models.CharField(max_length=100)
    budget = models.CharField(max_length=50)
    date = models.DateField(max_length=50)

class Progresses(models.Model):
    task = models.CharField(max_length=100)
    budget = models.CharField(max_length=100)
    date = models.CharField(max_length=50)
    status = models.CharField(max_length=100)
