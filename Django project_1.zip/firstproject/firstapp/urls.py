
from django.urls import path, include  # type: ignore
from .views import SignupPage, LoginPage, HomePage, DashBoard, AdminLogin, UserHome, AddTask, AdminPage, AdminDASH, HomeUser, BudgetManagement, AddManagement, Delete_budget, ViewTask, Delete_task, IndexPage, ContactUs, AboutUs, AddResource, ViewResource, Delete_resource, ResourceView, ProgressView, AddProgress, DeleteProgress

urlpatterns = [
    path('', IndexPage, name='index'),
    path('home/', HomePage, name='home.html'),
    path('signup/', SignupPage, name='signup'),
    path('login/', LoginPage, name='login'),
    path('dashboard/', DashBoard, name='dashboard'),
    path('admin_login/', AdminLogin, name="admin_login"),
    path('userhome/', UserHome, name="userhome"),
    path('addTask/', AddTask, name="addTask"),
    path('Admindashboard/', AdminPage, name='Admindashboard'),
    path('AdminDash/', AdminDASH, name='AdminDash'),
    path('homeuser/', HomeUser, name='homeuser'),
    path('budget/', BudgetManagement, name='budget'),
    path('addbudget/', AddManagement, name='addbudget'),
    path('deletebudget/<str:pk>/', Delete_budget, name='deletebudget'),
    path('viewtask/', ViewTask, name='viewtask'),
    path('delete-task/<str:pk>/', Delete_task, name='delete-task'),
    path('contactus/', ContactUs, name='contactus'),
    path('aboutus/', AboutUs, name='aboutus'),
    path('resource/', AddResource, name='resource'),
    path('viewResource/', ViewResource, name='viewResource'),
    path('delete-resource/<str:pk>/', Delete_resource, name='delete-resource'),
    path('userResource/', ResourceView, name='userResource'),
    path('progress/', ProgressView, name='progress'),
    path('addprogress/', AddProgress, name='addprogress'),
    path('delete-progress/<str:pk>/', DeleteProgress, name='delete-progress'),
]